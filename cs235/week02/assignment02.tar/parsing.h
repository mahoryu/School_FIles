/***********************************************************************
* Header:
*    PARSING
* Summary:
*    This class will take a input string and parse it out into words.
* Author
*    Ethan Holden, Adrian Lane
************************************************************************/

#ifndef PARSING_H
#define PARSING_H

#include <iostream>    // for ISTREAM and COUT
#include <sstream>     // for STRING STREAM
#include <vector>      // for VECTOR
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include "stack.h"     // for STACK
using namespace std;

class Parsing
{
  private:
   string s;
   string temp;
   vector <string> storage;

  public:
   Parsing(string s) { this->s = s; }
   
   void parse(string s);
   
   
};

void parse(string s)
{
   for (int i = 0; i < s.size(); i++)
   {
      temp += s.at(i);
      switch (s.at(i))
      {
         case '(':
            storage.push_back(temp);
            temp.clear();
            break;
         case ')':
            temp -= ')';
            
         case ' ':
            storage.push_back(temp);
            temp.clear;
            break;

   }
}

#endif // PARSING_H


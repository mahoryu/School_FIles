/***********************************************************************
 * Header File:
 *    Velocity 
 * Author:
 *    Ethan Holden
 * Summary:
 *    Contains the definition of the Velocity class
 ************************************************************************/

#ifndef VELOCITY_H
#define VELOCITY_H

#include <iostream>

/*********************************************
 * VELOCITY
 * Sets the current velocity of the moving
 * object.
 *********************************************/
class Velocity
{
  private:
   float dX;
   float dY;
   
  public:
   Velocity();
   Velocity(float dX, float dY);

   float getDx() const {float val = dX; return val;}
   float getDy() const {float val = dY; return val;}

   void setDx(float dX) {this->dX = dX;}
   void setDy(float dY) {this->dY = dY;}
};

#endif // VELOCITY_H

/***********************************************************************
 * Header File:
 *    Lander 
 * Author:
 *    Ethan Holden
 * Summary:
 *    Contaions the definition of the Lander class.
 ************************************************************************/


#ifndef LANDER_H
#define LANDER_H

#include "point.h"
#include "velocity.h"

/*********************************************
 * LANDER
 * The class that sets the information about
 * the lander itself.
 *********************************************/
class Lander
{
  private:
   Point position;
   Velocity velocity;
   float gravity;
   int fuel;
   bool alive;
   bool landed;
   
  public:
   Lander();
   Point getPoint()       const {Point val = position; return val;}
   Velocity getVelocity() const {Velocity val = velocity; return val;}
   bool isAlive()         const {bool val = alive; return val;}
   bool isLanded()        const {bool val = landed; return val;}
   int getFuel()          const {int val = fuel; return val;}
   bool canThrust();

   void setLanded(bool landed) {this->landed = landed;}
   void setAlive(bool alive)   {this->alive = alive;}
   void setFuel(int fuel)      {this->fuel = fuel;}

   void applyGravity(float gravity);
   void applyThrustLeft();
   void applyThrustRight();
   void applyThrustBottom();

   void advance();
   void draw();
};

#endif // LANDER_H

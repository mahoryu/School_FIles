/***********************************************************************
 * Source File:
 *    Lander 
 * Author:
 *    Ethan Holden
 * Summary:
 *    Contains the methods of the Lander class.
 ************************************************************************/

#include <iostream>
using namespace std;

#include "lander.h"
#include "uiDraw.h"
#include <cassert>

Lander :: Lander()
{
   gravity = 0.1;
   fuel = 500;
   alive = true;
   landed = false;
}

bool Lander :: canThrust()
{
}

void Lander :: applyGravity(float gravity)
{
}

void Lander :: applyThrustLeft()
{
}

void Lander :: applyThrustRight()
{
}

void Lander :: applyThrustBottom()
{
}

void Lander :: advance()
{
}

void Lander :: draw()
{
   drawLander(getPoint());
}
